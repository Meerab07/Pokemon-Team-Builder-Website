from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector
import bcrypt

app = Flask(__name__)
CORS(app)

db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "pokemon_team_builder"
}

@app.route('/')
def home():
    """Test endpoint to check if server is running"""
    return jsonify({
        "message": "Pokemon Team Builder API is running! 🚀",
        "status": "active"
    })

@app.route('/register', methods=['POST'])
def register():
    try:
        data = request.json
        name = data.get('name') 
        username = data.get('username')
        email = data.get('email')
        password = data.get('password') 
        
        # Validate all fields are present
        if not all([name, username, email, password]):
            return jsonify({
                "success": False, 
                "message": "All fields are required"
            }), 400

        # Hash the password
        hashed_pw = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        
        # Check if user already exists
        cursor.execute("SELECT id FROM users WHERE email = %s OR username = %s", (email, username))
        if cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({
                "success": False, 
                "message": "User already exists, please login"
            }), 400
        
        cursor.execute(
            "INSERT INTO users (name, username, email, password) VALUES (%s, %s, %s, %s)", 
            (name, username, email, hashed_pw)
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            "success": True,
            "message": "Registration successful! You can now login."
        }), 201
        
    except mysql.connector.Error as db_err:
        print(f"Database error in register: {db_err}")
        return jsonify({
            "success": False,
            "message": f"Database error: {str(db_err)}"
        }), 500
        
    except Exception as e:
        print(f"Error in register: {e}")
        return jsonify({
            "success": False,
            "message": "An error occurred during registration"
        }), 500

@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.json
        username = data.get('username')
        password = data.get('password')
        
        # Validate fields
        if not username or not password:
            return jsonify({
                "success": False,
                "message": "Username and password are required"
            }), 400

        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if not user:
            return jsonify({
                "success": False, 
                "message": "User not found, please try again"
            }), 404
        
        # Check password
        if bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
            return jsonify({
                "success": True,
                "message": "Login successful",
                "username": user['username'], 
                "user": {
                    "id": user['id'],
                    "name": user['name'],
                    "username": user['username'],
                    "email": user['email']
                }
            }), 200
        else:
            return jsonify({
                "success": False, 
                "message": "Incorrect password, please try again"
            }), 401
            
    except mysql.connector.Error as db_err:
        print(f"Database error in login: {db_err}")
        return jsonify({
            "success": False,
            "message": f"Database error: {str(db_err)}"
        }), 500
        
    except Exception as e:
        print(f"Error in login: {e}")
        return jsonify({
            "success": False,
            "message": "An error occurred during login"
        }), 500

if __name__ == '__main__':
    print("🚀 Starting Flask server...")
    print("📍 Server running at: http://127.0.0.1:5000")
    print("💡 Press CTRL+C to stop the server")
    print("📊 Database: pokemon_team_builder")
    app.run(debug=True, port=5000)