
# Pokemon Team Builder (React + Vite)

Quick start:

1. `npm install`
2. `npm run dev`

This project is a lightweight Pokemon team builder that fetches data from https://pokeapi.co.
Replace sample contact info in `src/pages/Contact.jsx` as needed.
