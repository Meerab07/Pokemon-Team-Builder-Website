import { useState, useEffect } from 'react'
import Login from './components/Login'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import TeamBuilder from './components/TeamBuilder'
import Contact from './pages/Contact'
import Privacy from './pages/Privacy'
import CookiesPage from './pages/Cookies'

export default function App(){
  const [user, setUser] = useState(null)
  const [route, setRoute] = useState('home') // home, contact, privacy, cookies, login
  const [showCookieModal, setShowCookieModal] = useState(false)
  const [cookiesAccepted, setCookiesAccepted] = useState(localStorage.getItem('ptb_cookies') === 'accepted')

  useEffect(()=>{
    if(!user){
      setRoute('login')
    } else {
      setRoute('home')
      if(!localStorage.getItem('ptb_cookies')){
        setShowCookieModal(true)
      }
    }
  },[user])

  function handleLogin(u){
    setUser(u)
  }

  function handleRoute(r){
    setRoute(r)
  }

  function acceptCookies(){
    localStorage.setItem('ptb_cookies','accepted')
    setCookiesAccepted(true)
    setShowCookieModal(false)
  }
  function declineCookies(){
    localStorage.setItem('ptb_cookies','declined')
    setCookiesAccepted(false)
    setShowCookieModal(false)
  }

  return (
    <div>
      <div className='container'>
        <header className='nav'> 
          <div className='logo'>Pokémon</div>

          <nav className='links'>
            {user && <a className='muted' onClick={()=>handleRoute('home')}>Home</a>}
            <a className='muted' onClick={()=>{handleRoute('contact')}}>Contact</a>
            <a className='muted' onClick={()=>{handleRoute('privacy')}}>Privacy Policy</a>
            {!user ? null : <a className='cta btn' onClick={()=>{setUser(null); setRoute('login')}} style={{marginLeft:8}}>Logout</a>}
          </nav>
        </header>

        <main>
          {!user && route === 'login' &&
            <Login onLogin={handleLogin} onRoute={handleRoute} />
          }
          {user && route === 'home' &&
            <TeamBuilder user={user} />
          }
          {route === 'contact' && <Contact onReturn={()=>setRoute(user? 'home':'login')} />}
          {route === 'privacy' && <Privacy onReturn={()=>setRoute(user? 'home':'login')} />}
          {route === 'cookies' && <CookiesPage onReturn={()=>setRoute('login')} />}
        </main>

        <Footer />
      </div>

      {showCookieModal && !cookiesAccepted && (
        <div className='cookie-modal card'>
          <h3>We use Cookies</h3>
          <p className='muted'>This site uses cookies to improve experience. You can accept or decline. For details click <a className='link' onClick={()=>setRoute('cookies')}>Cookies</a>.</p>
          <div style={{display:'flex',gap:10,justifyContent:'flex-end',marginTop:10}}>
            <button className='btn btn-ghost' onClick={declineCookies}>Decline</button>
            <button className='btn btn-primary' onClick={acceptCookies}>Accept</button>
          </div>
        </div>
      )}
    </div>
  )
}