
import React from 'react'
export default function Privacy({onReturn}){
  return (
    <div className='card'>
      <h2>Privacy Policy</h2>
      <p>We are committed to protecting your personal data in accordance with the UK Data Protection Act 2018 and the General Data Protection Regulation (GDPR). When you use our Pokémon team builder, we may collect limited personal information (such as your email address or preferences) solely to enhance your experience and improve our services. Your data will never be sold or shared with third parties without your explicit consent. We implement appropriate technical and organisational measures to safeguard your information, and you have the right to access, correct, or delete your data at any time. By using our site, you agree to this policy and the responsible handling of your data.</p>
      <h3>Cookies</h3>
      <p>We may use cookies to improve user experience. Users can accept or decline cookies on first visit.</p>
      <h3>Data Use</h3>
      <p>We do not transmit user credentials to any third party in this demo. User data is stored locally in your browser (localStorage).</p>
      <div style={{marginTop:12}}><button className='btn btn-ghost' onClick={onReturn}>Return</button></div>
    </div>
  )
}
