
import React from 'react'
export default function Cookies({onReturn}){
  return (
    <div className='card'>
      <h2>About Cookies</h2>
      <p>Cookies are small pieces of data stored by your browser that help websites remember preferences and improve experience.</p>
      <p><strong>Types used:</strong></p>
      <ul>
        <li><strong>Essential cookies</strong> - required to keep the site functional.</li>
        <li><strong>Analytics cookies</strong> - used to gather anonymous usage patterns.</li>
        <li><strong>Preference cookies</strong> - remember theme or language settings.</li>
      </ul>
      <p>Your privacy matters. In production, ensure you comply with GDPR and the Data Protection Act 2018, provide legal basis for processing personal data, and offer users clear ways to withdraw consent.</p>
      <div style={{marginTop:12}}><button className='btn btn-ghost' onClick={onReturn}>Return</button></div>
    </div>
  )
}
