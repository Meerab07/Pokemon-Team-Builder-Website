
import React from 'react'
export default function Contact({onReturn}){
  return (
    <div className='card'>
      <h2>Contact</h2>
      <p>If you'd like to reach out, replace these sample details with your own.</p>
      <ul>
        <li>Email: meerabpoketeam@gmail.com</li>
        <li>Twitter: @pokemee</li>
        <li>Instagram: @pokemee0</li>
      </ul>
      <div style={{marginTop:12}}><button className='btn btn-ghost' onClick={onReturn}>Return</button></div>
    </div>
  )
}
