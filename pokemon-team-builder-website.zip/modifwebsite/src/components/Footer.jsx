
import React from 'react'
export default function Footer(){
  return <footer className='footer'>Made with ❤️ — © 2025 All Rights Reserved.</footer>
}
