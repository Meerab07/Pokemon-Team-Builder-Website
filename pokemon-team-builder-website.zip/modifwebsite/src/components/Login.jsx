import { useState } from "react"

function Login({ onLogin, onRoute }) {
    const [isLogin, setIsLogin] = useState(true)
    const [form, setForm] = useState({
        name: "",
        username: "",
        email: "",
        password: ""
    })
    const [message, setMessage] = useState("")
    const [loading, setLoading] = useState(false)

    const handleChange = (e) => {
        setForm({...form, [e.target.name]: e.target.value})
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        setLoading(true)
        setMessage("")

        const endpoint = isLogin ? "http://127.0.0.1:5000/login" : "http://127.0.0.1:5000/register"
        const payload = isLogin 
            ? { username: form.username, password: form.password }
            : form

        try {
            const res = await fetch(endpoint, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            })

            const result = await res.json()
            
            if (isLogin) {
                if (result.success) {
                    setMessage(`Welcome ${result.username}!`)
                    // Call parent handler to set user
                    setTimeout(() => {
                        onLogin({ username: result.username })
                    }, 500)
                } else {
                    setMessage(result.message || "Login failed")
                }
            } else {
                setMessage(result.message)
                if (result.success) {
                    setTimeout(() => {
                        setIsLogin(true)
                        setForm({ name: "", username: "", email: "", password: "" })
                    }, 1500)
                }
            }
        } catch (error) {
            setMessage("Connection error. Make sure the server is running.")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="login-container">
            <div className="login-card card">
                <h2 className="login-title">
                    {isLogin ? "Welcome Back!" : "Create Account"}
                </h2>
                <p className="login-subtitle muted">
                    {isLogin ? "Login to build your Pokémon team" : "Join us to start building teams"}
                </p>

                <form onSubmit={handleSubmit} className="login-form">
                    {!isLogin && (
                        <div className="field">
                            <label>Full Name</label>
                            <input 
                                type="text" 
                                name="name" 
                                value={form.name}
                                onChange={handleChange}
                                placeholder="Enter your name"
                                required
                            />
                        </div>
                    )}

                    <div className="field">
                        <label>Username</label>
                        <input 
                            type="text" 
                            name="username" 
                            value={form.username}
                            onChange={handleChange}
                            placeholder="Choose a username"
                            required
                        />
                    </div>

                    {!isLogin && (
                        <div className="field">
                            <label>Email</label>
                            <input 
                                type="email" 
                                name="email" 
                                value={form.email}
                                onChange={handleChange}
                                placeholder="your@email.com"
                                required
                            />
                        </div>
                    )}

                    <div className="field">
                        <label>Password</label>
                        <input 
                            type="password" 
                            name="password" 
                            value={form.password}
                            onChange={handleChange}
                            placeholder="Enter your password"
                            required
                        />
                    </div>

                    <button 
                        type="submit" 
                        className="btn btn-primary btn-full"
                        disabled={loading}
                    >
                        {loading ? "Please wait..." : (isLogin ? "Login" : "Register")}
                    </button>

                    {message && (
                        <div className={`message ${message.includes('Welcome') || message.includes('success') ? 'success' : 'error'}`}>
                            {message}
                        </div>
                    )}
                </form>

                <div className="toggle-auth">
                    <p className="muted">
                        {isLogin ? "Don't have an account? " : "Already have an account? "}
                        <a 
                            className="link" 
                            onClick={() => {
                                setIsLogin(!isLogin)
                                setMessage("")
                                setForm({ name: "", username: "", email: "", password: "" })
                            }}
                        >
                            {isLogin ? "Register here" : "Login here"}
                        </a>
                    </p>
                </div>
            </div>
        </div>
    )
}

export default Login