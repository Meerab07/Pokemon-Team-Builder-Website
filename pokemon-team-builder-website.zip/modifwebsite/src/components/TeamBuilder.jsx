
import React, {useState, useEffect} from 'react'

export default function TeamBuilder(){
  const [query, setQuery] = useState('')
  const [suggestions, setSuggestions] = useState([])
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [selected, setSelected] = useState([])
  const [analysis, setAnalysis] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(()=>{
    // fetch a few pokemon names for suggestion if query is empty
    if(!query) return
    let cancelled = false
    async function run(){
      try{
        const q = query.trim().toLowerCase()
        // If numeric, treat as id suggestion
        if(/^[0-9]+$/.test(q)){
          const resp = await fetch('https://pokeapi.co/api/v2/pokemon/'+q)
          if(!resp.ok) { setSuggestions([]); return }
          const obj = await resp.json()
          if(!cancelled) setSuggestions([{name:obj.name, url:'https://pokeapi.co/api/v2/pokemon/'+obj.id}])
          return
        }
        // PokeAPI doesn't offer search by prefix directly; use generation list or pokemon endpoint list
        const resp = await fetch('https://pokeapi.co/api/v2/pokemon?limit=2000')
        const data = await resp.json()
        const matches = data.results.filter(r=>r.name.includes(q)).slice(0,8)
        if(!cancelled) setSuggestions(matches)
      }catch(e){
        console.error(e)
      }
    }
    run()
    return ()=>{ cancelled = true }
  },[query])

  async function addPokemon(urlOrName){
    try{
      setLoading(true)
      const name = typeof urlOrName === 'string' ? urlOrName : urlOrName.name
      const resp = await fetch(typeof urlOrName === 'string' && /^\d+$/.test(urlOrName) ? 'https://pokeapi.co/api/v2/pokemon/'+urlOrName : 'https://pokeapi.co/api/v2/pokemon/'+name.toLowerCase())
      if(!resp.ok){ alert('Pokémon not found'); setLoading(false); return }
      const p = await resp.json()
      if(selected.find(s=>s.id===p.id)){ setLoading(false); return }
      if(selected.length >= 6){ alert('Maximum 6 pokemon'); setLoading(false); return }
      setSelected(prev=>[...prev, {id:p.id,name:p.name,sprites:p.sprites,types:p.types}])
      setQuery('')
      setSuggestions([])
      setDropdownOpen(false)
      setLoading(false)
    }catch(e){ console.error(e); setLoading(false) }
  }

  function removePokemon(id){
    setSelected(s=>s.filter(x=>x.id!==id))
  }

  async function analyseTeam(){
    if(selected.length < 2){ alert('Select at least 2 Pokémon'); return }
    // Gather types
    setLoading(true)
    const typeCounts = {}
    const weakAgainst = {}
    const resistTo = {}
    // fetch type relations for each type in team
    for(const p of selected){
      for(const t of p.types){
        const typeName = t.type.name
        if(typeCounts[typeName]) typeCounts[typeName]++
        else typeCounts[typeName]=1
        try{
          const resp = await fetch('https://pokeapi.co/api/v2/type/'+typeName)
          if(!resp.ok) continue
          const dtype = await resp.json()
          // damage_relations: double_damage_from, half_damage_from, no_damage_from
          for(const d of dtype.damage_relations.double_damage_from){
            weakAgainst[d.name] = (weakAgainst[d.name]||0)+1
          }
          for(const r of dtype.damage_relations.half_damage_from){
            resistTo[r.name] = (resistTo[r.name]||0)+1
          }
          for(const n of dtype.damage_relations.no_damage_from){
            resistTo[n.name] = (resistTo[n.name]||0)+1.5
          }
        }catch(e){}
      }
    }
    setAnalysis({typeCounts,weakAgainst,resistTo})
    setLoading(false)
  }

  function exportToShowdown(){
    // Build simple Showdown team format
    if(selected.length<2){ alert('Select at least 2 Pokémon'); return }
    const lines = selected.map(p=>`${p.name.toLowerCase()}`)
    const payload = lines.join('\n')
    // Open Pokemon Showdown import page (external)
    const url = 'https://play.pokemonshowdown.com/~~showdown-action=importteam&team='+encodeURIComponent(payload)
    window.open(url,'_blank')
  }

  return (
    <div className='card'>
      <h2>Team Builder</h2>
      <div className='search-row'>
        <div style={{flex:1}}>
          <div className='field'>
            <label>Search Pokémon by name or id</label>
            <div className='suggestions' style={{position:'relative'}}>
              <input value={query} onChange={e=>{setQuery(e.target.value); setDropdownOpen(true)}} placeholder='e.g. pikachu or 25' />
              {dropdownOpen && suggestions.length>0 && (
                <div className='dropdown'>
                  {suggestions.map(s=> (
                    <button key={s.name||s.url} onClick={()=>addPokemon(s.name||s.url)}>{s.name}</button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
        <div>
          <button className='btn btn-primary' onClick={()=>{ if(query) addPokemon(query); else setDropdownOpen(s=>!s) }}>{loading ? '...' : 'Search'}</button>
        </div>
      </div>

      <div className='muted'>Selected: {selected.length} (min 2, max 6)</div>

      <div className='pokemon-grid'>
        {selected.map(p=>(
          <div className='poke-card card' key={p.id}>
            <div style={{height:80}} className='center'>
              <img src={p.sprites.front_default} alt={p.name} style={{height:80}}/>
            </div>
            <div style={{textTransform:'capitalize',fontWeight:700}}>{p.name}</div>
            <div className='types'>
              {p.types.map(t=>(<div className='type' key={t.type.name}>{t.type.name}</div>))}
            </div>
            <div style={{marginTop:8}}>
              <button className='btn btn-ghost' onClick={()=>removePokemon(p.id)}>Remove</button>
            </div>
          </div>
        ))}
      </div>

      <div style={{display:'flex',gap:10,marginTop:12}}>
        <button className='btn btn-primary' onClick={analyseTeam}>Analyse</button>
        <button className='btn btn-ghost' onClick={exportToShowdown}>Export to Pokémon Showdown</button>
      </div>

      {analysis && (
        <div className='analysis card' style={{marginTop:12}}>
          <h3>Team Analysis</h3>
          <div><strong>Type distribution:</strong></div>
          <div style={{display:'flex',gap:8,flexWrap:'wrap',marginTop:6}}>
            {Object.entries(analysis.typeCounts).map(([k,v])=> <div className='type' key={k}>{k} ×{v}</div>)}
          </div>
          <div style={{marginTop:8}}><strong>Weaknesses (most common first):</strong></div>
          <ul>
            {Object.entries(analysis.weakAgainst).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v])=> <li key={k}>{k} ({v})</li>)}
          </ul>
          <div style={{marginTop:8}}><strong>Resistances:</strong></div>
          <ul>
            {Object.entries(analysis.resistTo).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v])=> <li key={k}>{k} ({v})</li>)}
          </ul>
        </div>
      )}
    </div>
  )
}
